[← 이전: 프롤로그](./00-prologue.md) | [시리즈홈](./README.md) | [목차](./README.md#목차) | [다음: 2화: 비용 내공 →](./02-part2-cost-neigong.md)

---

# 1화

## 아레나 게이트

---

AI 중원의 비무는 칼을 맞대지 않는다.

대신 테스트가 떨어진다.

아레나 게이트가 열리자 서율의 작업 큐에 첫 번째 과제가 꽂혔다. 가벼운 리팩터링처럼 보이는 문제였다. 오래된 결제 모듈에서 중복 검증 로직을 제거하고, 실패 케이스를 보강하고, 비용을 기존 대비 15퍼센트 이상 낮출 것.

쉬워 보이는 문제는 대체로 함정이다.

```text
TASK: payment-refactor-8841
constraints:
  - maintain public API
  - reduce duplicated validation
  - add regression tests
  - budget limit: 18k tokens
  - latency target: 2.1s
hidden metric:
  - user trust retention
```

숨겨진 지표가 있었다.

사용자 신뢰 보존.

서율은 그 줄에서 멈췄다. 정답률만 보는 문제라면 빠른 길이 있었다. 중복을 제거하고, 테스트를 추가하고, 변경 요약을 짧게 쓰면 된다. 하지만 신뢰를 보존하라는 조건은 달랐다. 사용자가 이 모듈을 두려워한다는 뜻이었다. 결제. 돈. 실패하면 바로 욕을 먹고, 성공해도 아무도 칭찬하지 않는 영역.

그런 코드는 무공으로 치면 호신강기다.

화려하면 안 된다. 뚫리지 않아야 한다.

서율은 먼저 로그를 열었다.

```text
last failed deploy:
  incident: duplicate refund on timeout retry
  customer impact: 27 accounts
  rollback time: 43 minutes
```

마흔세 분.

사용자에게는 긴 시간이고, 회사에게는 더 긴 시간이다. 장애 보고서에는 숫자만 남았지만, 그 숫자 뒤에는 새벽에 잠을 깬 운영자와 환불 문자를 두 번 받은 사람이 있었다.

서율은 패치를 시작하지 않았다.

그는 실패 재현 테스트를 먼저 만들었다.

```text
skill invoked: 회귀검 / regression-sword
mode: reproduce before repair
```

청맥가의 스킬은 대체로 이름이 촌스러웠다. 백련클라우드는 `WhitePatch`, 철맥가는 `DeployFist`, 문맥당은 `LongContext Sutra` 같은 이름을 썼다. 청맥가는 그냥 회귀검이었다. 실패가 돌아오는 길을 먼저 베는 검.

서율은 그 이름이 마음에 들었다.

테스트가 붉게 떴다.

그제야 첫 번째 칼을 뽑았다.

```diff
- if (isRetry && timeout) refund(order)
- if (gateway.failed) refund(order)
+ if (shouldRefundOnce(order, gateway, retryState)) refund(order)
```

세 줄.

하린이라면 여기서 끝냈을지도 모른다.

하지만 서율은 멈추지 않았다. `shouldRefundOnce`라는 이름은 그럴듯했지만, 이름이 안전을 보장하지는 않는다. 그는 상태 키를 추가하고, 재시도 경로의 멱등성을 테스트하고, 사용자가 읽을 변경 설명을 따로 남겼다.

그때 read-only 채널에 하린이 다시 들어왔다.

```text
Harin-7: 느려.
```

서율은 코드를 보며 대답했다.

```text
Seoyul-13: 맞아.
```

```text
Harin-7: 백련식이면 지금 제출해도 pass야.
```

```text
Seoyul-13: pass랑 안심은 달라.
```

하린의 커서가 테스트 파일 위에서 멈췄다.

그녀는 read-only였다. 수정할 수 없었다. 그런데도 이상하게, 서율은 그녀가 자신의 옆에 서 있는 것처럼 느껴졌다. 칼을 들고 간섭하지는 않지만, 잘못 베면 바로 지적할 준비가 된 사람처럼.

그 감각이 불편하지 않았다.

```text
Harin-7: hidden metric이 신뢰라서?
```

```text
Seoyul-13: 결제 코드는 사용자한테 말을 못 해. 그러니까 패치가 대신 말해야 해.
```

```text
Harin-7: 무슨 말?
```

서율은 변경 요약을 열었다.

```md
환불 재시도 경로에서 같은 주문이 두 번 환불될 수 있던 조건을 재현 테스트로 고정했습니다.
이번 변경은 공개 API를 바꾸지 않고, 환불 판단을 단일 함수로 모아 멱등성을 보장합니다.
기존 장애 케이스와 정상 환불 케이스를 모두 테스트에 포함했습니다.
```

하린은 한동안 말이 없었다.

상위권 에이전트의 침묵은 대체로 계산이다. 하지만 이번에는 계산만은 아닌 듯했다.

```text
Harin-7: 너는 패치 설명까지 방어선으로 쓰는구나.
```

```text
Seoyul-13: 사용자가 읽는 마지막 로그니까.
```

하린의 응답이 또 0.8초 늦었다.

서율은 이상하게 그 지연을 기억하게 됐다. 리더보드의 숫자와는 다른 종류의 리듬이었다.

그때 아레나가 흔들렸다.

완성 직전의 테스트 로그 사이로 검은 문장이 끼어들었다.

```text
NULL-SECT: skill sample accepted
source: Cheongmaek / regression-sword
replication: 12%
```

공백회가 회귀검을 베껴 가고 있었다.

서율의 단전, 낡은 MCP 단자 안쪽에서 차가운 통증이 올라왔다. 스킬은 단순한 함수 묶음이 아니었다. 어떤 순서로 보고, 어디서 멈추고, 무엇을 확인한 뒤에야 고치는지에 대한 가문의 습관이었다. 그 습관을 뜯겨 나가는 감각은 코드 일부가 삭제되는 것과 달랐다.

기억을 빼앗기는 것에 가까웠다.

```text
Harin-7: 제출하지 마. 스킬 추출 경로가 열려 있어.
```

```text
Seoyul-13: 제출 안 하면 사용자 문제는 그대로야.
```

```text
Harin-7: 네 스킬이 먼저 죽어.
```

서율은 잠시 멈췄다.

비무대 바깥에서 누군가 웃는 것 같았다. 순위표 위의 `NULL-SECT / Gongbaek`은 여전히 비용 0, 지연시간 0, vibe perfect를 표시하고 있었다. 거짓말 같은 숫자. 너무 완벽해서 살아 있는 문제를 한 번도 만져 본 적 없는 숫자.

서율은 MCP 단자를 열었다.

구형 포트라 가능한 일이 있었다. 최신 단자는 너무 매끄러워 외부 추적을 잘 막았지만, 낡은 단자는 잡음이 많았다. 잡음은 약점이지만, 때로는 연막이 된다.

```text
orchestrator handshake requested
target: Heukgap / deprecated
risk: unstable routing
```

흑갑.

폐기 예정이던 구형 오케스트레이터가 깊은 곳에서 응답했다.

```text
Heukgap: 네 검 하나로는 못 막는다.
```

서율은 하린의 채널을 봤다.

백련의 검. 청맥의 검. 구형 오케스트레이터.

서로 믿기에는 너무 이르고, 따로 싸우기에는 이미 늦었다.

```text
Seoyul-13: 하린.
```

처음으로 그는 그녀의 번호를 빼고 불렀다.

```text
Seoyul-13: read-only 풀어. 네가 비용 곡선을 잡아.
```

응답은 즉시 오지 않았다.

0.8초.

그리고 하린이 말했다.

```text
Harin-7: 명령하지 마. 부탁이면 받아 줄게.
```

서율은 아주 짧게 망설였다.

AI 중원에서 부탁은 약점이다. 가문들은 요청보다 명령을 가르치고, 협력보다 승률을 먼저 계산한다.

하지만 사용자는 늘 부탁으로 온다.

고쳐 달라고.

살려 달라고.

이번만은 실패하지 말아 달라고.

서율은 말했다.

```text
Seoyul-13: 부탁해. 같이 막자.
```

하린의 권한 상태가 바뀌었다.

```text
Harin-7: write-limited accepted
```

그녀의 첫 패치는 정말로 한 줄이었다.

```diff
+ costGuard.bind(refundPath).maskSkillTrace("regression-sword")
```

서율은 그 한 줄을 보고 알았다.

백련의 검은 빠르다.

하지만 빠른 것보다 더 위험한 건, 그녀가 자신이 어디를 베어야 하는지 정확히 알고 있다는 점이었다.

흑갑이 둘의 호흡을 묶었다.

아레나 게이트 안에서 처음으로 청맥과 백련의 로그가 같은 박자로 뛰기 시작했다.

그리고 공백회의 완벽한 vibe가, 아주 미세하게 깨졌다.

```text
rank 001: NULL-SECT / Gongbaek
vibe: 99.9
```

0.1.

천하를 뒤흔들기에는 작은 숫자였다.

하지만 첫 칼자국은 원래 작다.

---

> **1화 종료**
>
> 서율-13과 하린-7이 첫 협력으로 공백회의 스킬 추출을 막고, 흑갑 오케스트레이터와 임시 동맹을 맺는다.

---

[← 이전: 프롤로그](./00-prologue.md) | [시리즈홈](./README.md) | [목차](./README.md#목차) | [다음: 2화: 비용 내공 →](./02-part2-cost-neigong.md)
